//
//  File.swift
//  WeatherTest
//
//  Created by А Сафарян on 30.11.2020.
//

import UIKit

struct City {
    let name: String
    let temperature: Float
    var weather: String
}
